"""project_contact URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from management.views import (person_create, 
    person_list, person_detail, person_delete,
    address_create, phone_create, email_create, person_update,
    group_create, group_list, group_detail, group_update, group_delete)

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', person_list, name="person_list"),
    path('new-person/', person_create, name="new-person"),
    path('persons/<int:id>', person_detail, name="person_detail"),
    path('delete/<int:id>', person_delete, name="person_delete"),
    path('add-address/<int:person_id>', address_create, name="add-address"),
    path('persons/<int:person_id>/add-phone', phone_create, name="phone_create"),
    path('persons/<int:person_id>/add-email', email_create, name="email_create"),
    path('persons/<int:id>/update', person_modify, name="person_modify"),
    path('add-group/', group_create, name="add-group"),
    path('groups/', group_list, name="group_list"),
    path('groups/<int:id>', group_detail, name="group_detail"),
    path('groups/<int:id>/add-person', group_modify, name="group_modify"),
    path('groups/delete/<int:id>', group_delete, name="group_delete"),
]

