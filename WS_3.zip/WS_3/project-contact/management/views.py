from django.shortcuts import render, redirect
from django.http import HttpResponse
from management.models import Person, Address, PhoneNumber

def person_list(request):
    persons = Person.objects.all() 
    context = {"persons":persons}
    return render(request, "person_list.html", context)

def person_create(request):
    if request.method == "GET":
        return render(request, "person_create.html")

    if request.method == "POST":
        person_name = request.POST["name"]
        person_surname = request.POST["surname"]
        person_description = request.POST["description"]

        person = Person.objects.create(
            name=person_name, 
            surname=person_surname, 
            description=person_description)

        return redirect("person_list")

def person_detail(request, id):
    try:
        person = Person.objects.get(pk=id)
    except Person.DoesNotExist:
        return HttpResponse("Person doesn't exists")
    context = {
        "person": person}
    return render(request, "person_detail.html", context)

def person_delete(request, id):
    try:
        person = Person.objects.get(pk=id)
    except Person.DoesNotExist:
        return HttpResponse("Person doesn't exists")

    context = {"person": person}

    if request.method == "GET":
        return render(request, "person_delete.html", context)

    if request.method == "POST":
        person.delete()
        return redirect("person_list")

def person_update(request, id):
    try:
        person = Person.objects.get(pk=id)
    except Person.DoesNotExist:
        return HttpResponse("Person doesn't exists")

    context = {"person": person}

    if request.method == "GET":
        return render(request, "person_update.html", context)

    if request.method == "POST":
        person_name = request.POST["name"]
        person_surname = request.POST["surname"]
        person_description = request.POST["description"]

        person.name = person_name
        person.surname = person_surname
        person.description = person_description
        person.save()

        return redirect("person_detail", id=person.id)

def address_create(request, person_id):
    try:
        person = Person.objects.get(pk=person_id)
    except Person.DoesNotExist:
        return HttpResponse("Person doesn't exists")

    context = {"person": person}

    if request.method == "GET":     
        return render(request, "address_create.html", context)

    if request.method == "POST":
        address = Address()
        address.city = request.POST["city"]
        address.street = request.POST["street"]
        address.postal_code = request.POST["postal code"]
        address.person = person
        address.save()

        return redirect("person_detail", id=person.id)

def phone_create(request, person_id):
    try:
        person = Person.objects.get(pk=person_id)
    except Person.DoesNotExist:
        return HttpResponse("Person doesn't exists")

    context = {"person": person}

    if request.method == "GET":     
        return render(request, "phone_create.html", context)

    if request.method == "POST":
        phone = Phone()
        phone.home_number = request.POST["home_number"]
        phone.work_number = request.POST["work_number"]
        phone.person = person
        phone.save()

        return redirect("person_detail", id=person.id)

def group_list(request):
    groups = Group.objects.all() 
    context = {"groups":groups}
    return render(request, "group_list.html", context)

def group_create(request):
    if request.method == "GET":
        return render(request, "group_create.html")

    if request.method == "POST":
        
        group.save()

        return redirect("group_list")

def group_detail(request, id):
    try:
        group = Group.objects.get(pk=id)
    except Group.DoesNotExist:
        return HttpResponse("group doesn't exists")
    context = {
        "group": group}
    return render(request, "group_detail.html", context)

def group_modify(request, id):
    try:
        group = Group.objects.get(pk=id)
    except Group.DoesNotExist:
        return HttpResponse("Group doesn't exists")

    context = {"group": group}

    if request.method == "GET":
        return render(request, "group_modify.html", context)

    if request.method == "POST":
        group = Group()
        return redirect("group_detail", id=group.id)

def group_delete(request, id):
    try:
        group = Group.objects.get(pk=id)
    except Group.DoesNotExist:
        return HttpResponse("Group doesn't exists")

    context = {"group": group}

    if request.method == "GET":
        return render(request, "group_delete.html", context)