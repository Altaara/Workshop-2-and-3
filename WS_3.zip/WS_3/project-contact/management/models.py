from django.db import models

class Person(models.Model):
    name = models.CharField(max_length=64)
    surname = models.CharField(max_length=64)
    description = models.CharField(max_length=64)

class Address(models.Model):
    city = models.CharField(max_length=255)
    street = models.CharField(max_length=255)
    house_number = models.IntegerField()
    flat_number = models.IntegerField()
    postal_code = models.IntegerField()
    person = models.ForeignKey(Person, on_delete=models.CASCADE)

class Phone(models.Model):
    home_number = models.IntegerField()
    work_number = models.IntegerField()
    person = models.ForeignKey(Person, on_delete=models.CASCADE)

class Email(models.Model):
    email_home = models.CharField(max_length=64)
    email_work = models.CharField(max_length=64)
    person = models.ForeignKey(Person, on_delete=models.CASCADE)

class Group(models.Model):
    name = models.CharField(max_length=64)
    persons = models.ManyToManyField(Person)